import './App.css';
import Main from './containers/Main/Main';

function App() {
  return (
    <div className="App">
      <div className="name-and-date">
        26/07/21 - Yariv Shenkar
      </div>

      <header className="App-header">
        <span className="attenti">
          <span className="attenti-first-letter">a</span>
          ttenti
        </span>
        exercise
      </header>

      <Main/>
    </div>
  );
}

export default App;
