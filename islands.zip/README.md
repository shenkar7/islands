# Attenti Home Assignment
Using breadth-first search, the program finds how many islands are visible in the matrix.
